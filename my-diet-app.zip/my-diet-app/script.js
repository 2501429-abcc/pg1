// --- 初期設定 ---
let savedData = localStorage.getItem('myMeals');
let meals = savedData ? JSON.parse(savedData) : [];
let editId = null;

const addBtn = document.getElementById('add-btn');
const mealDate = document.getElementById('meal-date');
const mealMenu = document.getElementById('meal-menu');
const mealTime = document.getElementById('meal-time');
const mealMemo = document.getElementById('meal-memo');
const mealList = document.getElementById('meal-list');
const filterDate = document.getElementById('filter-date');
const showAllBtn = document.getElementById('show-all-btn');
const clearAllBtn = document.getElementById('clear-all-btn');
const totalCountDisplay = document.getElementById('total-count');

// --- 起動時処理 ---
const today = new Date().toISOString().split('T')[0];
mealDate.value = today;
filterDate.value = today;
displayMeals();

// --- APIからカロリーを取得する関数 ---
async function fetchCalories(query) {
    try {
        const res = await fetch(`/api/search?query=${encodeURIComponent(query)}`);
        const data = await res.json();
        return data.foods && data.foods.length > 0 ? Math.round(data.foods[0].nf_calories) : 0;
    } catch (error) {
        console.error("API Error:", error);
        return 0;
    }
}

// --- 記録・更新イベント ---
addBtn.addEventListener('click', async function() {
    if (!mealMenu.value) { alert("メニューを入力してください"); return; }
    
    addBtn.disabled = true;
    const originalBtnText = addBtn.innerText;
    addBtn.innerText = "計算中...";

    // APIから本物のカロリーを取得
    const calories = await fetchCalories(mealMenu.value);

    if (editId) {
        const index = meals.findIndex(m => m.id === editId);
        meals[index] = { 
            ...meals[index], 
            date: mealDate.value, 
            menu: mealMenu.value, 
            calories: calories, // カロリー更新
            time: mealTime.value, 
            memo: mealMemo.value 
        };
        editId = null;
        addBtn.innerText = "記録する";
    } else {
        const newMeal = { 
            id: Date.now(), 
            date: mealDate.value, 
            menu: mealMenu.value, 
            calories: calories, // 新規カロリー
            time: mealTime.value, 
            memo: mealMemo.value 
        };
        meals.push(newMeal);
    }
    
    addBtn.disabled = false;
    addBtn.innerText = "記録する";
    save();
    mealMenu.value = ''; 
    mealMemo.value = '';
    displayMeals();
});

// --- 表示処理（日付グループ化 + カロリー合計） ---
function displayMeals() {
    mealList.innerHTML = '';
    const targetDate = filterDate.value;
    const filteredMeals = meals.filter(item => !targetDate || item.date === targetDate);
    
    // 表示中の合計カロリー計算
    const totalCal = filteredMeals.reduce((sum, item) => sum + (item.calories || 0), 0);
    totalCountDisplay.innerText = `表示中の合計: ${totalCal} kcal / ${filteredMeals.length}件`;

    const groups = {};
    filteredMeals.forEach(item => { 
        if (!groups[item.date]) groups[item.date] = [];
        groups[item.date].push(item);
    });

    for (const date in groups) {
        const section = document.createElement('div');
        section.className = 'date-section';
        section.innerHTML = `<h2 class="date-title">${date}</h2>`;
        
        const row = document.createElement('div');
        row.className = 'meal-row';

        groups[date].forEach(item => {
            const div = document.createElement('div');
            div.className = 'meal-item';
            div.innerHTML = `
                <p><strong>[${item.time}]</strong></p>
                <p>${item.menu} <span style="color:#e94e77; font-weight:bold;">${item.calories || 0} kcal</span></p>
                <p><small>${item.memo || ""}</small></p>
            `;

            const btnGroup = document.createElement('div');
            btnGroup.className = 'btn-group';

            const editBtn = document.createElement('button');
            editBtn.innerText = '編集';
            editBtn.onclick = () => {
                mealDate.value = item.date;
                mealMenu.value = item.menu;
                mealTime.value = item.time;
                mealMemo.value = item.memo;
                editId = item.id;
                addBtn.innerText = "更新する";
                window.scrollTo({ top: 0, behavior: 'smooth' }); 
            };

            const delBtn = document.createElement('button');
            delBtn.innerText = '削除'; 
            delBtn.onclick = () => { 
                if(confirm("削除しますか？")) {
                    meals = meals.filter(m => m.id !== item.id);
                    save(); displayMeals(); 
                }
            };

            btnGroup.append(editBtn, delBtn);
            div.appendChild(btnGroup);
            row.appendChild(div);
        });
        section.appendChild(row);
        mealList.appendChild(section);
    }
}

// --- 共通処理 ---
function save() { localStorage.setItem('myMeals', JSON.stringify(meals)); }
filterDate.addEventListener('change', displayMeals);
showAllBtn.addEventListener('click', () => { filterDate.value = ""; displayMeals(); });
clearAllBtn.addEventListener('click', () => { 
    if(confirm("全消去しますか？")){ meals = []; save(); displayMeals(); }
});

export default async function handler(req, res) {
    const { query } = req.query;
    const APP_ID = process.env.NUTRITIONIX_APP_ID;
    const APP_KEY = process.env.NUTRITIONIX_APP_KEY;

    if (!query) {
        return res.status(400).json({ error: "Query is required" });
    }

    try {
        const response = await fetch('https://trackapi.nutritionix.com/v2/natural/nutrients', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'x-app-id': APP_ID,
                'x-app-key': APP_KEY
            },
            body: JSON.stringify({ query: query })
        });
        const data = await response.json();
        res.status(200).json(data);
    } catch (err) {
        res.status(500).json({ error: "Failed to fetch data from API" });
    }
}